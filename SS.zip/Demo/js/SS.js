// 轮播框
slideFrame()
// 列表
List()
// 导航栏
NavBar()
// 下拉菜单
DropdownMenu()
// 选项栏
OptionBar()
// 预览框
PreviewFrame()
// 适配响应式js框架
function all() {
    // 轮播框
    slideFrame()
    // 列表
    List()
    // 导航栏
    NavBar()
    // 选项栏
    OptionBar()
    // 预览框
    PreviewFrame()
}/*
var Timer = null
window.onresize = function () {
    if (Timer !== null) {
        clearTimeout(Timer)
    }
    Timer = setTimeout(() => {
        console.log('变化')
        all()
    }, 100);
}*/
function List () {
    var AllList = document.querySelectorAll('.List')
    
    for (var index_AllList = 0; index_AllList < AllList.length; ++index_AllList) {
        // 所有List
        let root = AllList[index_AllList]
        // 当前遍历的List的父元素
        let parent = null
        // 当前遍历的List的父元素的宽度
        let parentwidth = 0 
        // 当前遍历的List的父元素的高度
        let parentheight = 0 

        // 当列表为下拉
        if (root.className.indexOf('LiDropDown') !== -1) {
            // 判断是否拥有容器
            if (root.parentNode.className.indexOf('LiContainer') !== -1) {
                parent = root.parentNode
                parentwidth = parent.offsetWidth
            }

            // 是否拥有容器
            if (parent !== null) {
                root.style.width = parentwidth + 22 + 'px'
                
                // 获取所有Menu
                let allmenu = root.querySelectorAll('.Menu')

                // 为所有Menu添加设置
                for (var index_allmenu = 0; index_allmenu < allmenu.length; ++index_allmenu) {
                    allmenu[index_allmenu].style.width = parentwidth + 'px'
                    let title = allmenu[index_allmenu].querySelector('.Title')
                    title.style.height = allmenu[index_allmenu].offsetHeight + 'px'

                    // 为Menu添加点击事件
                    title.dataset.open = 'false'
                    title.addEventListener('click', (event) => {
                        let root = event.currentTarget
                        let parent = root.parentNode
                        let whole = parent.querySelector('.Whole')
                        let itemlength = whole.children.length
                        let maxheight = itemlength *  whole.querySelector('.Item').offsetHeight
                        

                        if (root.dataset.open.indexOf('false') !== -1) {
                            root.dataset.open = 'open'
                            whole.style.maxheight = maxheight + 'px'
                            parent.style.height = maxheight + root.offsetHeight + 'px'
                            console.log('打开')
                        } else if (root.dataset.open.indexOf('open') !== -1) {
                            root.dataset.open = 'false'
                            whole.style.maxheight = ''
                            parent.style.height = ''
                            console.log('关闭')
                        }
                    })
                }
            } else {
            }
            // 当列表为树
        } else if (root.className.indexOf('LiTree') !== -1) {
            // 当前选择的Menu的索引
            var Cache = 0
            // 遍历根元素
            let traversalRoot = (root,marginleft) => {
                let nodelist = root.children

                for (var index_nodelist = 0; index_nodelist < nodelist.length; ++index_nodelist) {

                    let node = nodelist[index_nodelist]
                    if (node.className === 'Root') {
                        node.style.marginLeft = marginleft + '%'
                    } else {
                        traversalRoot(node, marginleft + marginleft / 2)
                    }
                }
            }
            // 自定义左边距
            let marginleft = 0
            marginleft = root.dataset.marginLeft * 1
            traversalRoot(root, marginleft)
            
        } else {
            // 当前选择的Menu的索引
            var Cache = 0
            // 是否拥有容器
            if (root.parentNode.className.indexOf('LiContainer') !== -1) {
                parent = root.parentNode
                parentwidth = parent.offsetWidth
                parentheight = parent.offsetHeight

                // 获取所有Menu
                let allmenu = root.querySelectorAll('.Menu')

                // 设置Listwidth
                root.style.width = parentwidth + 20 + 'px'
                // 设置List最大高度
                root.style.maxHeight = parentheight + 'px'

                // 配置所有Menu的宽度
                for (var index_allmenu = 0;index_allmenu < allmenu.length;index_allmenu++) {
                    // 设置所有Menu的宽度
                    allmenu[index_allmenu].style.width = parentwidth + 'px'
                    // 为每个Menu添加索引
                    allmenu[index_allmenu].dataset.index = index_allmenu
                    // 为每个Menu添加点击事件
                    allmenu[index_allmenu].addEventListener('click', (event) => {
                        let root = event.currentTarget
                        
                        allmenu[Cache].style.background = ''
                        Cache = root.dataset.index * 1
                        
                        if (!!root.style.background) {
                            root.style.background = ''
                        } else {
                            root.style.background = 'hsla(0, 0%, 0%, 0.1)'
                        }
                    })
                }
            } else {

            }
        }
    }
}
// 导航栏
function NavBar () {
    var AllNavBar = document.querySelectorAll('.NavBar')

    for (var index_AllNavBar = 0; index_AllNavBar < AllNavBar.length; ++index_AllNavBar) {
        var root = AllNavBar[index_AllNavBar]
        
        // option高度
        let optionheight = 0
        // optionlist 最大高度
        let optionlistmaxheight = 0
        // 移动端按钮
        let mobile = root.querySelector('.Mobile')
        // Option父类
        let optionlist = root.querySelector('.OptionList')
        // 所有Option
        let alloption = optionlist.querySelectorAll('.Option')
        // 设置Option点击效果
        // option点击索引缓存
        let currentoption = 0
        for (var index_alloption = 0;index_alloption < alloption.length; ++index_alloption) {
            let option = alloption[index_alloption]
            // 为option添加索引
            option.dataset.index = index_alloption
            // 添加点击事件
            option.addEventListener('click', (event) => {
                let root = event.currentTarget
                
                // 获取当前option索引
                let index = option.dataset.index
                // 删除之前的option点击效果
                alloption[currentoption].classList.remove('ClickOption')
                // 更新option点击索引缓存
                currentoption = index
                // 为当前点击的option添加点击效果
                alloption[currentoption].classList.add('ClickOption')
            })
        }
        // 添加移动端点击事件
        mobile.dataset.state = 'close'
        mobile.addEventListener('click', (event) => {
            let root = event.currentTarget
            let parent = root.parentNode
            
            

            if (mobile.dataset.state.indexOf('close') !== -1) {
                // 将当前状态设置为open
                mobile.dataset.state = 'open'
                // 获取option的高度用以设置OptioniLIst的最大高度
                optionheight = optionlist.querySelector('.Option').offsetHeight
                // 获取option的数量
                let optionquan = parent.querySelector('.OptionList').querySelectorAll('.Option').length
                // 根据option的数量设置optionlist的maxheight
                optionlistmaxheight = optionheight * optionquan
                optionlist.style.maxHeight = optionlistmaxheight + 'px'
                optionlist.dataset.maxHeight = optionlistmaxheight
            } else if (mobile.dataset.state.indexOf('open') !== -1) {
                mobile.dataset.state = 'close'
                optionlist.style.maxHeight = ''
            }
        })
        if (root.className.indexOf('NBDropDown') !== -1) {

            for (var index_alloption = 0; index_alloption < alloption.length; ++ index_alloption) {
                let option = alloption[index_alloption]

                
                // 当屏幕宽度小于900(视为移动端)
                if (window.innerWidth <= 900) {
                    if (option.querySelector('.Whole') !== null) {
                        option.addEventListener('mouseenter', (event) => {
                            let root = event.currentTarget
                            let whole = root.querySelector('.Whole')
                            let itemheight = whole.querySelector('.Item').offsetHeight
                            let itemquan = whole.querySelectorAll('.Item').length
                            let index = option.dataset.index * 1 
                            //  打开whole
                            optionlist.style.height = (index + 1) * optionheight + itemheight * itemquan + 'px'
                            optionlist.style.maxHeight = (index + 1) * optionheight + itemheight * itemquan + 'px'
                            whole.style.height = itemheight * itemquan + 'px'
                        })
                        option.addEventListener('mouseleave', (event) => {
                            let root = event.currentTarget
                            let whole = root.querySelector('.Whole')
        
                            optionlist.style.height =  optionlistmaxheight + 'px'
                            optionlist.style.maxHeight =  optionlistmaxheight + 'px'
                            whole.style.height = ''
        
                        })
                    }
                } else {
                    if (option.querySelector('.Whole') !== null) {
                        option.addEventListener('mouseenter', (event) => {
                            let root = event.currentTarget
                            let whole = root.querySelector('.Whole')
                            let itemheight = whole.querySelector('.Item').offsetHeight
                            let itemquan = whole.querySelectorAll('.Item').length
    
                            whole.style.height = itemheight * itemquan + 'px'
                            
                        })
                        option.addEventListener('mouseleave', (event) => {
                            let root = event.currentTarget
                            let whole = root.querySelector('.Whole')
        
                            whole.style.height = ''
        
                        })
                    }
                }
                
            }
        } else {

        }
    }
}
// 下拉菜单
function DropdownMenu () {
    var AllDropdownMenu = document.querySelectorAll('.DropdownMenu')
    for(var index_AllDropdownMenu = 0;index_AllDropdownMenu < AllDropdownMenu.length; ++index_AllDropdownMenu) {
        var DropdownMenu = AllDropdownMenu[index_AllDropdownMenu]
        var Title = DropdownMenu.querySelector('.Title')
        Title.dataset.state = 'close'
        Title.addEventListener('click',(event) => {
            let root = DropdownMenu
            let menu = root.querySelector('.Menu')
            
            if (Title.dataset.state.indexOf('close') !== -1) {
                Title.dataset.state = 'open'
                let itemquan = menu.querySelectorAll('.Item').length
                let itemheight = menu.querySelector('.Item').offsetHeight
                DropdownMenu.classList.add('DDMClick')
                console.log(itemquan + ' ' + itemheight)
                menu.style.maxHeight = itemquan * itemheight + 'px'
            } else if (Title.dataset.state.indexOf('open') !== -1) {
                Title.dataset.state = 'close'
                menu.style.maxHeight = ''
                DropdownMenu.classList.remove('DDMClick')
            }
        })
    }
}
// 弹出栏
function PopBar (el) {
    var Root = document.querySelector(el)
    var ClosePopBar = Root.querySelector('.ClosePopBar')

    Root.dataset.state = 'close'
    if (ClosePopBar !== null) {
        ClosePopBar.addEventListener('click', (event) => {
            Root.style.left = ''
            Root.style.right = ''
        })
    }
    if (Root.dataset.state.indexOf('close') !== -1) {
        Root.dataset.state = 'open'
        Root.style.left = '0%'
        Root.style.right = '0%'
    } else if (Root.dataset.state.indexOf('open') !== -1) {
        Root.dataset.state = 'close'
        Root.style.left = ''
        Root.style.right = ''
    }
}
// 选项栏
function OptionBar () {
    
    var AllOptionBar = document.querySelectorAll('.OptionBar')
    
    for (var index_AllOptionBar = 0; index_AllOptionBar < AllOptionBar.length; ++index_AllOptionBar) {
        var Root = AllOptionBar[index_AllOptionBar]
        
        var OBContainer = Root.querySelector('.OBContainer')
        var OptionList = OBContainer.querySelector('.OptionList')
        var AllOption = OptionList.querySelectorAll('.Option')
        var ContentList = Root.querySelector('.ContentList')
        var AllContent = ContentList.querySelectorAll('.Content')
        var OptionListWidth = OBContainer.offsetWidth
        // 当前选择的Option的索引
        var Cache = 0

        OptionList.style.width = OptionListWidth + 20 + 'px'
        AllOption[Cache].style.background = 'hsla(0, 0%, 0%, 0.2)'
        AllContent[Cache].style.zIndex = 1
        // 给所有Option添加设置
        for (var index_AllOption = 0; index_AllOption < AllOption.length; ++index_AllOption) {
            let root = AllOption[index_AllOption]

            root.style.width = OptionListWidth + 'px'
            root.dataset.index = index_AllOption

            root.addEventListener('click', (event) => {
                let root = event.currentTarget
                let index = root.dataset.index * 1
                AllContent[Cache].style.zIndex = -99
                AllOption[Cache].style.background = ''
                Cache = index
                AllContent[Cache].style.zIndex = 1
                AllOption[Cache].style.background = 'hsla(0, 0%, 0%, 0.2)'
            })
        }

    }

}
// 预览框
function PreviewFrame () {
    var AllPreviewFrame = document.querySelectorAll('.PreviewFrame')

    for (var index_PreviewFrame = 0;index_PreviewFrame < AllPreviewFrame.length; ++index_PreviewFrame) {
        var Root = AllPreviewFrame[index_PreviewFrame]
        var Preview = Root.querySelector('.Preview')
        var Detail = Root.querySelector('.Detail')
        var ClosePreviewFrame = Detail.querySelector('.ClosePreviewFrame')

        Preview.addEventListener('click', (event) => {
            let root = event.currentTarget
            let parent = root.parentNode

            parent.querySelector('.Detail').style.opacity = '1'
            parent.querySelector('.Detail').style.transform = 'scale(1, 1)'
        })
        if (ClosePreviewFrame !== null) {
            ClosePreviewFrame.addEventListener('click', (event) => {
                let root = event.currentTarget
                let topnode = null
                let getTopNode = function (node) {
                    var root = node
                    
                    if (root.className.indexOf('PreviewFrame') !== -1 && root.className.indexOf('ClosePreviewFrame') === -1) {
                        return root
                    } else {
                        return getTopNode(root.parentNode)
                    }

                    return null
                }
                topnode = getTopNode(root)
                topnode.querySelector('.Detail').style.opacity = ''
                topnode.querySelector('.Detail').style.transform = ''
            })
        }
    }
}
// 轮播框
function slideFrame () {
    
    var AllSlideFrame = document.querySelectorAll('.SlideFrame')
    for (var index_AllSlideFrame = 0; index_AllSlideFrame < AllSlideFrame.length; ++index_AllSlideFrame) {

        var Root = AllSlideFrame[index_AllSlideFrame]
        var Slide =  Root.querySelector('.Content > .Slide')
        var pos = 0
        var IndicatorCache = 0
    
        // 添加指示器面板
        var IndicatorBar_dom = document.createElement('div')
        IndicatorBar_dom.className = 'IndicatorBar'

        // 设置图片位置
        var ItemList = Slide.querySelectorAll('.Item')
        for (index = 0; index < ItemList.length; ++index) {
            ItemList[index].style.left = 100 * index + '%'

            // 添加指示器
            let indicator_dom = document.createElement('div')
            indicator_dom.className = 'Indicator'
            indicator_dom.dataset.itemPos = index
            IndicatorBar_dom.append(indicator_dom)
        }
        // 添加指示器面板
        Root.querySelector('.Content').append(IndicatorBar_dom)
    
        // 选择指示器面板
        var IndicatorBar = Root.querySelector('.Content > .IndicatorBar')
        // 设置指示器显示
        var setIndicator = (IndicatorBar) => {
            IndicatorBar.querySelectorAll('.Indicator')[IndicatorCache].style.background = '#0080e9'
            IndicatorCache = Math.abs(pos / 100)
            IndicatorBar.querySelectorAll('.Indicator')[IndicatorCache].style.background = 'hsla(0, 0%, 100%, 0.7)'
        }
        // 设置当前已选择指示器
        IndicatorBar.querySelectorAll('.Indicator')[IndicatorCache].style.background = 'hsla(0, 0%, 100%, 0.7)'
    
        // 设置指示器事件
        let indicatorlist = IndicatorBar.querySelectorAll('.Indicator')
    
        for (index = 0; index <= indicatorlist.length - 1; ++index) {
            indicatorlist[index].addEventListener('click', (event) => {
                let currentel = event.currentTarget
                let root = currentel.parentNode.parentNode
                let thepos = currentel.dataset.itemPos

                pos = thepos * -100 
                root.querySelector('.Slide').style.left = pos + '%'
                setIndicator(currentel.parentNode)
            })
        }

        // 图片向左
        var left = Root.querySelector('.Left')
    
        if (left !== null) {
            left.addEventListener('click', (event) => {
                let root = event.currentTarget.parentNode
                let slide =  root.querySelector('.Content > .Slide')
                let indicatorBar = root.querySelector('.Content > .IndicatorBar')

                if (pos < 0) {
                    pos = pos + 100
                    slide.style.left = pos + '%'
                    setIndicator(indicatorBar)
                }
            })
        }
        // 图片向右
        var right = Root.querySelector('.Right')
        if (right !== null) {
            right.addEventListener('click', (event) => {
                let root = event.currentTarget.parentNode
                let indicatorBar = root.querySelector('.Content > .IndicatorBar')
                let slide = root.querySelector('.Content > .Slide')
                let ItemListQuan = slide.querySelectorAll('.Item').length

                if (pos > (ItemListQuan - 1) * -100) {
                    pos = pos - 100
                    slide.style.left = pos + '%'
                    setIndicator(indicatorBar)
                }
            })
        }
    }
}
// 文件上传 
function uploadOption (url, init) {
    var el = document.querySelector(init.el)
    var setName = null
    var setLoading = null
    var callBack = null
    var InputFile = el.querySelector('input[type="file"]')

    el.addEventListener('click', (event) => {
        InputFile.click()
    })

    setName = init.setName && init.setName
    setLoading = init.setLoading && init.setLoading
    callBack = init.callBack && init.callBack

    InputFile.addEventListener('change', (event) => {
       for (let index = 0;index < InputFile.files.length; ++index) {
           let file = InputFile.files[index]
           let name = file.name
           let size = file.size
           let block_quan = 0
           let block = 0
           let file_info = new FormData()
           let cache = 0
           let file_block = new FormData()

           const blocksize = init.size * 1024 * 1024
           
           if (size % blocksize === 0) {
            block_quan = size / blocksize
           } else {
            block_quan = (size - size % blocksize) / blocksize
            block_quan += 1
           }

           file_info.append('type', 'info')
           file_info.append('name', name)
           file_info.append('size', size)

           fetch(url, {
               method: 'POST',
               body: file_info
           }).then(data => {
               if (callBack !== undefined && callBack !== null) {
                   callBack(data)
               }
           }).catch(result => {
               console.log(result)
           })
           setLoading(0)
           for (let quan = 0; quan < block_quan; ++quan) {
               block = file.slice(quan * blocksize, (quan + 1) * blocksize)
               file_block.delete('quan')
               file_block.delete('pos')
               file_block.delete('block')

               file_block.append('type', 'block')
               file_block.append('name', name)
               file_block.append('quan', quan)
               file_block.append('pos', quan * blocksize)
               file_block.append('size', size)
               file_block.append('block', block)

               if (quan === 0) {
                if (setName !== undefined && setName !== null) {
                    setName(name)
                   }
               }
               fetch(url, {
                method: 'POST',
                body: file_block
            }).then(data => {
                file_block = null

                if (setLoading!== undefined && setLoading !== null) {
                    if (quan > cache) {
                        cache = quan
                    }
                    setLoading(cache / block_quan)
                    if ((cache + 1) === block_quan) {
                        setLoading(1)
                    }
                }
                
            }).catch(result => {
                console.log(result)
            })
           }
       }
    })
}
// 提示栏
function TipsBar (el) {

    var Root = document.querySelector(el)
    var CloseTipsBar = Root.querySelector('.CloseTipsBar')
    
    if (Root.dataset.state === undefined) {
        Root.dataset.state = 'close'
    }
    if (Root.dataset.state.indexOf('close') !== -1) {
        Root.dataset.state = 'open'
        Root.style.display = 'block'
    } else if (Root.dataset.state.indexOf('open') !== -1) {
        Root.dataset.state = 'close'
        Root.style.display = 'none'
    }
    if (CloseTipsBar !== null) {
        CloseTipsBar.addEventListener('click', () => {
            Root.dataset.state = 'close'
            Root.style.display = 'none'
        })
    }
}